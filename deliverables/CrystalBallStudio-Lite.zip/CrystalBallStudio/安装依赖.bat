@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo 正在准备独立水晶球软件，请使用 Python 3.12 或 3.13...
where py >nul 2>nul
if errorlevel 1 (
  python -c "import sys; assert sys.version_info[:2] in ((3,12),(3,13)), 'Please install Python 3.12 or 3.13'"
  if errorlevel 1 goto failed
  python -m venv .venv
) else (
  py -3.12 -c "import sys" >nul 2>nul
  if errorlevel 1 (
    py -3.13 -m venv .venv
  ) else (
    py -3.12 -m venv .venv
  )
)
if errorlevel 1 goto failed
if exist "wheels" (
  echo 正在使用随包提供的Python 3.12 Windows离线依赖...
  .venv\Scripts\python.exe 核验离线依赖.py
  if errorlevel 1 goto failed
  .venv\Scripts\python.exe -m pip install --disable-pip-version-check --no-index --find-links wheels -r requirements-windows.lock
  if not errorlevel 1 goto installed
  echo 离线依赖与当前Python版本不匹配，正在尝试联网安装...
)
.venv\Scripts\python.exe -m pip install --disable-pip-version-check -r requirements-windows.lock
if errorlevel 1 goto failed
:installed
echo 安装完成。现在可以双击“启动水晶球工作室.bat”。
pause
exit /b 0
:failed
echo 安装失败。请检查 Python、网络及上方错误信息。
pause
exit /b 1
