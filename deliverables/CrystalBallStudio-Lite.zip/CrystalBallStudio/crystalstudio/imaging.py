from __future__ import annotations

import math
import os
from pathlib import Path
import uuid

from PIL import Image, ImageDraw, ImageFilter, ImageFont, ImageOps

from .config import StudioError

EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff"}


def load_image(path: Path) -> Image.Image:
    try:
        with Image.open(path) as original:
            if original.width * original.height > 50_000_000:
                raise StudioError(f"图片过大：{path.name}，请先缩小到5000万像素以内。")
            return ImageOps.exif_transpose(original).convert("RGBA")
    except (OSError, Image.DecompressionBombError) as exc:
        raise StudioError(f"无法读取图片：{path.name}") from exc


def bbox_valid(box) -> tuple[float, float, float, float]:
    if not isinstance(box, list) or len(box) != 4 or any(type(v) not in (int, float) or not math.isfinite(v) for v in box):
        raise StudioError("AI返回的主体坐标无效。")
    left, top, right, bottom = map(float, box)
    if not (0 <= left < right <= 1 and 0 <= top < bottom <= 1):
        raise StudioError("AI返回的主体坐标超出范围。")
    if right - left < .05 or bottom - top < .05:
        raise StudioError("主体占比过小，无法可靠提取。")
    return left, top, right, bottom


def crop_product(image: Image.Image, box) -> Image.Image:
    l, t, r, b = bbox_valid(box)
    return image.crop((int(l * image.width), int(t * image.height), math.ceil(r * image.width), math.ceil(b * image.height)))


def subject_bounds(image: Image.Image) -> tuple[int, int, int, int]:
    alpha = image.getchannel("A")
    # Exclude tiny nearly-transparent artifacts, while keeping the original soft alpha for compositing.
    bounds = alpha.point(lambda x: 255 if x >= 12 else 0).getbbox()
    lo, hi = alpha.getextrema()
    if bounds is None or lo > 5 or hi < 128:
        raise StudioError("提取图缺少有效透明背景或没有可见主体，请重新生成。")
    if bounds[2] - bounds[0] < 64 or bounds[3] - bounds[1] < 64:
        raise StudioError("提取主体过小，请换用清晰源图。")
    return bounds


def atomic_image(image: Image.Image, path: Path, *, jpeg: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name("." + path.name + "." + uuid.uuid4().hex + ".tmp")
    try:
        if jpeg:
            if image.mode == "RGBA":
                background = Image.new("RGB", image.size, "white")
                background.paste(image, mask=image.getchannel("A"))
                image = background
            image.convert("RGB").save(temp, format="JPEG", quality=96, subsampling=0)
        else:
            image.save(temp, format="PNG")
        temp.replace(path)
    finally:
        temp.unlink(missing_ok=True)


def composite_scene(background: Image.Image, subject: Image.Image, size: int) -> Image.Image:
    canvas = ImageOps.fit(background.convert("RGBA"), (size, size), Image.Resampling.LANCZOS)
    bounds = subject_bounds(subject)
    product = subject.crop(bounds)
    product.thumbnail((round(size * .47), round(size * .58)), Image.Resampling.LANCZOS)
    x = (size - product.width) // 2
    y = round(size * .79) - product.height
    shadow = Image.new("RGBA", (size, size))
    draw = ImageDraw.Draw(shadow)
    draw.ellipse((x + product.width * .08, size * .775, x + product.width * .92, size * .81), fill=(42, 31, 19, 95))
    shadow = shadow.filter(ImageFilter.GaussianBlur(size * .011))
    canvas.alpha_composite(shadow)
    canvas.alpha_composite(product, (x, y))
    return canvas.convert("RGB")


def font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    roots = [
        Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts" / ("arialbd.ttf" if bold else "arial.ttf"),
        Path("/usr/share/fonts/truetype/dejavu") / ("DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf"),
    ]
    for candidate in roots:
        if candidate.exists():
            return ImageFont.truetype(str(candidate), size)
    return ImageFont.load_default(size=size)


def centered(draw: ImageDraw.ImageDraw, xy, text: str, f, fill) -> None:
    bounds = draw.textbbox((0, 0), text, font=f)
    draw.text((xy[0] - (bounds[2] - bounds[0]) / 2, xy[1]), text, font=f, fill=fill)


def dimension_layout(subject: Image.Image, globe_box, size: int = 1200) -> Image.Image:
    """Measure sphere diameters; the 6cm version is exactly 3/4 the linear scale of 8cm."""
    l, t, r, b = bbox_valid(globe_box)
    bounds = subject_bounds(subject)
    if l * subject.width < bounds[0] - 5 or r * subject.width > bounds[2] + 5:
        raise StudioError("球体测量坐标超出主体范围，无法绘制尺寸图。")
    if abs((r - l) * subject.width / ((b - t) * subject.height) - 1) > .25:
        raise StudioError("球体测量坐标不接近圆形，请重新识别。")
    canvas = Image.new("RGBA", (size, size), (244, 243, 239, 255))
    draw = ImageDraw.Draw(canvas)
    ink = "#173e51"
    scale = size / 1200
    centered(draw, (size / 2, 62 * scale), "WHAT MAKES IT SPECIAL", font(round(54 * scale), True), ink)
    centered(draw, (size / 2, 143 * scale), "Two sizes. The same warm glow.", font(round(27 * scale)), "#66777d")
    product = subject.crop(bounds)
    globe_width = (r - l) * subject.width
    baseline = 710 * scale
    for center_x, target_diameter, label in ((390 * scale, 340 * scale, "8cm"), (870 * scale, 255 * scale, "6cm")):
        ratio = target_diameter / globe_width
        resized = product.resize((max(1, round(product.width * ratio)), max(1, round(product.height * ratio))), Image.Resampling.LANCZOS)
        x, y = round(center_x - resized.width / 2), round(baseline - resized.height)
        canvas.alpha_composite(resized, (x, y))
        globe_top = y + (t * subject.height - bounds[1]) * ratio
        globe_bottom = y + (b * subject.height - bounds[1]) * ratio
        arrow_x = x + resized.width + 25 * scale
        draw.line((arrow_x, globe_top, arrow_x, globe_bottom), fill=ink, width=max(2, round(3 * scale)))
        tip = 8 * scale
        for yy, sign in ((globe_top, 1), (globe_bottom, -1)):
            draw.line((arrow_x - tip, yy + sign * tip, arrow_x, yy, arrow_x + tip, yy + sign * tip), fill=ink, width=max(2, round(3 * scale)))
        centered(draw, (center_x, 740 * scale), label, font(round(44 * scale), True), ink)
    draw.line((90 * scale, 829 * scale, 1110 * scale, 829 * scale), fill="#d4d9d5", width=max(1, round(2 * scale)))
    labels = [
        (90, 870, "Clear Crystal Glass", "Transparent globe with fine detail"),
        (650, 870, "Natural Wood Base", "A simple, warm natural finish"),
        (90, 995, "Warm LED Glow", "Soft golden light, clear glass"),
        (650, 995, "Two Globe Diameters", "8cm and 6cm options"),
    ]
    for x, y, title, detail in labels:
        draw.text((x * scale, y * scale), title, fill=ink, font=font(round(27 * scale), True))
        draw.text((x * scale, (y + 46) * scale), detail, fill="#5e727a", font=font(round(21 * scale)))
    centered(draw, (size / 2, 1145 * scale), "Dimensions refer to the glass globe diameter.", font(round(19 * scale)), "#6f797a")
    return canvas.convert("RGB")


def fit_guide(path: Path, size: int) -> Image.Image:
    image = load_image(path).convert("RGB")
    # Fit without cropping text from either of the fixed instructional cards.
    fitted = ImageOps.contain(image, (size, size), Image.Resampling.LANCZOS)
    canvas = Image.new("RGB", (size, size), "white")
    canvas.paste(fitted, ((size - fitted.width) // 2, (size - fitted.height) // 2))
    return canvas
