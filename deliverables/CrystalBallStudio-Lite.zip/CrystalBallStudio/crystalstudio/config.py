from __future__ import annotations

import json
import os
import sys
from dataclasses import asdict, dataclass, fields
from pathlib import Path
from urllib.parse import urlparse


class StudioError(Exception):
    """An actionable, safe-to-display application error."""


def user_directory() -> Path:
    override = os.environ.get("CRYSTAL_STUDIO_HOME")
    if override:
        return Path(override).expanduser().resolve()
    if sys.platform == "win32":
        return Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "CrystalBallStudio"
    return Path.home() / ".config" / "crystal-ball-studio"


@dataclass
class Settings:
    base_url: str = "https://api.openai.com/v1"
    vision_model: str = "gpt-6"
    image_model: str = "gpt-image-1.5"
    input_dir: str = ""
    output_dir: str = ""
    photo_guide: str = ""
    diy_guide: str = ""
    recursive: bool = False
    quality: str = "medium"
    size: int = 1200
    title_language: str = "English"
    title_limit: int = 180

    @classmethod
    def from_dict(cls, data: dict) -> "Settings":
        allowed = {f.name for f in fields(cls)}
        return cls(**{k: v for k, v in data.items() if k in allowed})

    @classmethod
    def load(cls) -> "Settings":
        path = user_directory() / "settings.json"
        if not path.exists():
            return cls()
        try:
            return cls.from_dict(json.loads(path.read_text(encoding="utf-8")))
        except (OSError, ValueError, TypeError) as exc:
            raise StudioError("设置文件无法读取，请检查 settings.json。") from exc

    def save(self) -> None:
        self.validate_connection()
        root = user_directory()
        root.mkdir(parents=True, exist_ok=True)
        target = root / "settings.json"
        temp = target.with_suffix(".tmp")
        temp.write_text(json.dumps(asdict(self), ensure_ascii=False, indent=2), encoding="utf-8")
        temp.replace(target)

    def validate_connection(self) -> None:
        if not isinstance(self.base_url, str):
            raise StudioError("API地址格式错误。")
        parsed = urlparse(self.base_url)
        local = parsed.hostname in {"localhost", "127.0.0.1", "::1"}
        if not parsed.hostname or not (parsed.scheme == "https" or (local and parsed.scheme == "http")):
            raise StudioError("API地址须使用HTTPS；本机测试接口可以使用HTTP。")
        if parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise StudioError("API地址不能包含账号、密码、查询参数或片段。")
        if not self.vision_model.strip() or not self.image_model.strip():
            raise StudioError("请填写账户实际可用的视觉/标题模型和GPT图像模型名。")
        if "deepseek" in self.image_model.lower() or "deepseek" in self.vision_model.lower():
            raise StudioError("本工具使用GPT视觉、标题与图像接口。")
        if self.quality not in {"low", "medium", "high"}:
            raise StudioError("图像质量应为low、medium或high。")
        if type(self.size) is not int or not 800 <= self.size <= 2400:
            raise StudioError("输出尺寸应在800到2400像素之间。")
        if type(self.title_limit) is not int or not 30 <= self.title_limit <= 500:
            raise StudioError("标题长度应在30到500字符之间。")
        if type(self.recursive) is not bool:
            raise StudioError("递归扫描选项格式错误。")


def api_key(session_key: str = "") -> str:
    key = session_key.strip() or os.environ.get("CRYSTAL_API_KEY", "").strip()
    if not key:
        raise StudioError("请在设置面板输入API Key，或设置CRYSTAL_API_KEY环境变量。密钥只保留在本次会话。")
    return key
