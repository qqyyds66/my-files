"""Independent crystal globe product studio."""

__version__ = "1.0.0"
