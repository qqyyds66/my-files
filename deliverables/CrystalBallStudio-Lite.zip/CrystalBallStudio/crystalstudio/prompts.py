DETECTION = """Inspect the supplied product photo. This task is ONLY visual product selection,
not title writing or copyright/brand classification. Select ONE primary product only if it is
a round transparent glass crystal globe placed directly on a simple cylindrical natural
wood-colored base with a lamp. Colored illumination is allowed; the glass itself must be clear.
Reject metal claw stands, transparent acrylic stands, dark plastic/electronic bases, heart-shaped
crystals, crystal blocks, bare globes without the required wooden base, unrelated products,
ambiguous crowded collages, and photos whose primary product cannot be confidently isolated.
If several copies of the SAME eligible product appear, select the largest unobstructed copy.
Do not select an inset portrait, a face alone, decorative objects, a photo frame, or packaging.
bbox must encompass the complete globe AND its own wooden base, excluding other objects as
far as possible, with a little margin. Coordinates are fractions of the upright input image.
pattern is a literal short visual description of the engraving INSIDE the globe, not a title.
Return the requested JSON. Confidence must reflect certainty, not optimism."""

DETECTION_SCHEMA = {
    "type": "object", "additionalProperties": False,
    "properties": {
        "eligible": {"type": "boolean"},
        "confidence": {"type": "number"},
        "reason": {"type": "string"},
        "bbox": {"type": "array", "items": {"type": "number"}, "minItems": 4, "maxItems": 4},
        "pattern": {"type": "string"},
    },
    "required": ["eligible", "confidence", "reason", "bbox", "pattern"],
}

EXTRACTION = """Edit only the ONE primary round crystal-glass globe AND its natural wood-colored
cylindrical base shown in this reference crop. Isolate that complete product on a fully transparent
background. Remove surrounding scene, hands, props, inset portraits, promotional text and other
products. Preserve the exact engraving/portrait/pattern and any lettering INSIDE the globe,
its identity, geometry, detail and placement; never invent or replace the engraving. Preserve the
base shape, natural light wood grain, relative proportions and camera angle. Make the base's
LED illumination a soft luminous warm yellow-white, with physically plausible golden highlights
passing THROUGH transparent clear glass. The globe must remain colorless transparent glass,
not opaque yellow, yellow painted material, an amber solid ball, or a yellow color overlay.
Keep fine realistic refraction and legible engraving. No background, cast shadow, floating product,
new text, watermark, border, metal stand or extra object. The whole product must fit inside the
frame with a small clear margin. High fidelity product photography, PNG with alpha."""

VERIFICATION = """Compare image 1 (original crop) with image 2 (normalized extracted product).
Is image 2 the SAME transparent round crystal globe on the SAME natural wood-colored base,
with the SAME internal engraving/portrait and proportions? It should be illuminated by warm
yellow-white light while the globe stays transparent/colorless. Reject changed faces/patterns,
opaque/tinted yellow glass, wrong base, extra products, props, missing product parts or lost detail.
Return ok, confidence, reason and globe_bbox: the bounds of ONLY the round glass globe in image 2,
excluding its base, in normalized [left, top, right, bottom] coordinates. This measures its DIAMETER,
not the height of the globe plus base. If you cannot verify fidelity, return ok=false."""

VERIFY_SCHEMA = {
    "type": "object", "additionalProperties": False,
    "properties": {
        "ok": {"type": "boolean"}, "confidence": {"type": "number"},
        "reason": {"type": "string"},
        "globe_bbox": {"type": "array", "items": {"type": "number"}, "minItems": 4, "maxItems": 4},
    }, "required": ["ok", "confidence", "reason", "globe_bbox"],
}

SCENES = (
    ("温暖床头", "an elegant oak bedside table, neutral linen bedding behind, softly blurred warm bedside lamp"),
    ("书房桌面", "a refined natural oak writing desk, soft cream wall, understated books far behind, gentle window light"),
    ("客厅边桌", "a high-end Scandinavian living room side table in pale oak, a neutral sofa blurred in the distance"),
    ("礼物角落", "a refined light-wood console, small closed beige gift box at the far left background, tasteful neutral interior"),
)


def background_prompt(index: int) -> str:
    _, description = SCENES[index]
    return f"""Photorealistic premium ecommerce lifestyle BACKGROUND ONLY: {description}.
Square composition, physically believable residential scale, calm high-end styling, cream and
natural wood palette, soft warm studio/daylight, realistic perspective, no strange fantasy objects.
There is NO product in this image. Keep a large clean empty tabletop in the central foreground,
covering x=25%-75% and y=35%-82%. The surface where a small lamp will later be placed is at
y=79% of the frame. Eye-level product-camera view with gently visible horizontal tabletop.
Objects remain at the outer edges or far background. NO glass globe, crystal, sphere, ball,
lamp product, people, hands, watermark, captions or text. The center must be empty. No split
panel or collage. Consistent soft upper-left light and restrained realistic colors."""

BACKGROUND_VERIFY = """Is this a plausible premium interior background with a clear EMPTY
central tabletop, suitable for placing one small crystal lamp? The central product placement
area x=25%-75%, y=35%-82% must be empty. Reject any existing glass globe, crystal lamp, duplicate
product, person, hand, central obstruction, prominent text, surreal geometry or strange scene.
Return ok and reason. This is a background-layout check, not a title or copyright check."""
BACKGROUND_SCHEMA = {
    "type": "object", "additionalProperties": False,
    "properties": {"ok": {"type": "boolean"}, "reason": {"type": "string"}},
    "required": ["ok", "reason"],
}

TITLE_SCHEMA = {
    "type": "object", "additionalProperties": False,
    "properties": {"title": {"type": "string"}}, "required": ["title"],
}
