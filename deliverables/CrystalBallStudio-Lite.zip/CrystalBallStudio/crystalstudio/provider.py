from __future__ import annotations

import base64
import io
import json

import httpx
from PIL import Image

from .config import Settings, StudioError


class GPTProvider:
    """Official Responses and GPT Image HTTP APIs; no hidden model fallback."""

    def __init__(self, settings: Settings, key: str):
        settings.validate_connection()
        self.settings = settings
        self.key = key
        self.client = httpx.Client(
            base_url=settings.base_url.rstrip("/") + "/",
            headers={"Authorization": f"Bearer {key}"},
            timeout=httpx.Timeout(600, connect=30),
            follow_redirects=False,
        )

    def close(self):
        self.client.close()

    def _request(self, method: str, route: str, **kwargs) -> dict:
        try:
            response = self.client.request(method, route, **kwargs)
        except httpx.HTTPError as exc:
            raise StudioError("AI请求连接失败或超时；本次请求可能已被服务端处理。已保留完成的步骤，可稍后继续。") from exc
        if not response.is_success:
            message = ""
            try:
                error = response.json().get("error", {})
                if isinstance(error, dict):
                    message = str(error.get("message", ""))
            except ValueError:
                pass
            message = message.replace(self.key, "[密钥已隐藏]")[:700]
            raise StudioError(f"AI接口返回HTTP {response.status_code}。{message or '请检查地址、模型权限、余额和请求格式。'}")
        try:
            data = response.json()
        except ValueError as exc:
            raise StudioError("AI接口返回了非JSON响应，请检查API地址。") from exc
        if not isinstance(data, dict):
            raise StudioError("AI接口响应格式错误。")
        return data

    def check_models(self, *, images: bool = True) -> list[str]:
        data = self._request("GET", "models")
        models = [item["id"] for item in data.get("data", []) if isinstance(item, dict) and isinstance(item.get("id"), str)]
        needed = [self.settings.vision_model] + ([self.settings.image_model] if images else [])
        missing = [name for name in needed if name not in models]
        if missing:
            raise StudioError("账户模型列表中没有：" + "、".join(missing) + "。请填写账户实际可用名称；GPT-6需要相应服务端支持。")
        return models

    @staticmethod
    def image_bytes(image: Image.Image) -> bytes:
        stream = io.BytesIO()
        image.save(stream, "PNG")
        return stream.getvalue()

    def vision(self, prompt: str, images: list[Image.Image], schema: dict, *, name: str = "product_check") -> dict:
        content = [{"type": "input_text", "text": prompt}]
        for image in images:
            copy = image.copy()
            copy.thumbnail((1600, 1600), Image.Resampling.LANCZOS)
            encoded = base64.b64encode(self.image_bytes(copy)).decode("ascii")
            content.append({"type": "input_image", "image_url": "data:image/png;base64," + encoded, "detail": "high"})
        data = self._request("POST", "responses", json={
            "model": self.settings.vision_model,
            "input": [{"role": "user", "content": content}],
            "text": {"format": {"type": "json_schema", "name": name, "schema": schema, "strict": True}},
        })
        if data.get("status") not in {None, "completed"}:
            raise StudioError("视觉/标题响应未完成，请检查模型权限和服务端限制。")
        texts = []
        for item in data.get("output", []):
            if item.get("type") == "message":
                for part in item.get("content", []):
                    if part.get("type") == "refusal":
                        raise StudioError("模型未执行当前请求，请查看输入图片是否适合处理。")
                    if part.get("type") == "output_text":
                        texts.append(part.get("text", ""))
        try:
            result = json.loads("".join(texts))
        except (ValueError, TypeError) as exc:
            raise StudioError("视觉/标题模型没有返回符合要求的JSON结果。") from exc
        if not isinstance(result, dict):
            raise StudioError("视觉/标题结果不是JSON对象。")
        return result

    def _decode_image(self, data: dict) -> Image.Image:
        try:
            entries = data["data"]
            encoded = entries[0]["b64_json"]
            if not isinstance(encoded, str) or len(encoded) > 100_000_000:
                raise ValueError("invalid image size")
            raw = base64.b64decode(encoded, validate=True)
            with Image.open(io.BytesIO(raw)) as image:
                if image.width * image.height > 25_000_000:
                    raise ValueError("image too large")
                image.load()
                return image.convert("RGBA")
        except (KeyError, IndexError, ValueError, OSError, TypeError) as exc:
            raise StudioError("GPT图像接口须返回有效的b64_json图像。") from exc

    def extract(self, image: Image.Image, prompt: str) -> Image.Image:
        data = self._request("POST", "images/edits", data={
            "model": self.settings.image_model, "prompt": prompt,
            "size": "1024x1024", "quality": "high", "n": "1",
            "background": "transparent", "output_format": "png", "input_fidelity": "high",
        }, files={"image": ("reference.png", self.image_bytes(image), "image/png")})
        return self._decode_image(data)

    def background(self, prompt: str) -> Image.Image:
        return self._decode_image(self._request("POST", "images/generations", json={
            "model": self.settings.image_model, "prompt": prompt,
            "size": "1024x1024", "quality": self.settings.quality,
            "n": 1, "background": "opaque", "output_format": "png",
        }))
