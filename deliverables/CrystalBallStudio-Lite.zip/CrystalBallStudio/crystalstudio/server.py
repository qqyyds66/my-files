from __future__ import annotations

from dataclasses import asdict
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import mimetypes
from pathlib import Path
import secrets
import subprocess
import sys
import threading
from urllib.parse import parse_qs, urlparse

from .config import Settings, StudioError, api_key
from .pipeline import Cancelled, Pipeline
from .provider import GPTProvider


def resource_root() -> Path:
    return Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parents[1]))


class State:
    def __init__(self, settings: Settings | None = None, provider_factory=GPTProvider):
        self.settings = settings or Settings.load()
        self.session_key = ""
        self.token = secrets.token_urlsafe(32)
        self.provider_factory = provider_factory
        self.lock = threading.RLock()
        self.cancel = threading.Event()
        self.running = False
        self.stage = "等待开始"
        self.logs = []
        self.results = []
        self.current = 0
        self.total = 0
        self.current_file = ""
        self.error = ""
        self.title = ""

    def event(self, event: dict):
        with self.lock:
            if event.get("message"):
                self.stage = event["message"]
                self.logs.append({"time": datetime.now().strftime("%H:%M:%S"), "text": event["message"]})
                self.logs = self.logs[-250:]
            self.total = event.get("total", self.total)
            self.current = event.get("current", self.current)
            self.current_file = event.get("file", self.current_file)
            if "result" in event:
                self.results.append(event["result"])

    def public(self) -> dict:
        with self.lock:
            return {"running": self.running, "stage": self.stage, "logs": self.logs[:],
                    "results": self.results[:], "current": self.current, "total": self.total,
                    "file": self.current_file, "error": self.error, "title": self.title}

    def start(self, kind: str, payload: dict):
        with self.lock:
            if self.running:
                raise StudioError("已有任务正在运行，请等待完成或停止当前任务。")
            settings = Settings.from_dict(asdict(self.settings))
            settings.validate_connection()
            key = api_key(self.session_key)
            if kind not in {"batch", "title", "connection"}:
                raise StudioError("未知任务。")
            self.cancel.clear()
            self.running = True
            self.error = ""
            self.stage = "准备连接GPT服务…"
            if kind == "batch":
                self.results = []
                self.current = self.total = 0
                self.current_file = ""
            if kind == "title":
                self.title = ""

        def work():
            provider = None
            try:
                provider = self.provider_factory(settings, key)
                pipeline = Pipeline(settings, provider, cancel=self.cancel, notify=self.event)
                if kind == "batch":
                    results = pipeline.run()
                    counts = {name: sum(r["status"] == name for r in results) for name in ("completed", "reused", "skipped", "failed")}
                    self.event({"message": f"批处理结束：完成{counts['completed']}，复用{counts['reused']}，跳过{counts['skipped']}，失败{counts['failed']}。"})
                elif kind == "title":
                    provider.check_models(images=False)
                    image_path = payload.get("image", "").strip()
                    title = pipeline.titles(str(payload.get("text", "")), image=Path(image_path) if image_path else None)
                    with self.lock:
                        self.title = title
                    self.event({"message": "独立标题处理已完成。"})
                else:
                    provider.check_models(images=True)
                    self.event({"message": "连接成功，视觉/标题模型和GPT图像模型均在账户可用列表中。"})
            except Cancelled as exc:
                self.event({"message": str(exc)})
            except (StudioError, OSError, ValueError, TypeError) as exc:
                safe = str(exc).replace(key, "[密钥已隐藏]")
                with self.lock:
                    self.error = safe
                self.event({"message": safe})
            except Exception:
                with self.lock:
                    self.error = "处理发生异常。请保留任务记录，重启后重试。"
                self.event({"message": self.error})
            finally:
                if provider:
                    provider.close()
                with self.lock:
                    self.running = False

        threading.Thread(target=work, daemon=True).start()


def browse(kind: str) -> str:
    # This intentionally selects local Windows files, rather than uploading source images to a website.
    try:
        import tkinter as tk
        from tkinter import filedialog
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        try:
            if kind == "folder":
                result = filedialog.askdirectory(parent=root)
            else:
                result = filedialog.askopenfilename(parent=root, filetypes=[("图片", "*.jpg *.jpeg *.png *.webp *.bmp *.tif *.tiff"), ("全部", "*.*")])
            return result or ""
        finally:
            root.destroy()
    except Exception as exc:
        raise StudioError("当前机器无法打开原生文件选择框，请直接填写完整文件路径。") from exc


def make_server(state: State, port: int = 0) -> ThreadingHTTPServer:
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, format, *args):
            pass

        def authorized(self) -> bool:
            return secrets.compare_digest(self.headers.get("X-Studio-Token", ""), state.token)

        def send_json(self, value, status=200):
            raw = json.dumps(value, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(raw)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
            self.wfile.write(raw)

        def send_file(self, path: Path):
            if not path.is_file():
                self.send_json({"error": "文件不存在。"}, 404)
                return
            raw = path.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", mimetypes.guess_type(str(path))[0] or "application/octet-stream")
            self.send_header("Content-Length", str(len(raw)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
            self.wfile.write(raw)

        def host_valid(self):
            parsed = urlparse("http://" + self.headers.get("Host", ""))
            return parsed.hostname in {"127.0.0.1", "localhost"}

        def do_GET(self):
            if not self.host_valid():
                self.send_json({"error": "非法主机。"}, 403)
                return
            parsed = urlparse(self.path)
            if parsed.path.startswith("/api/"):
                if not self.authorized():
                    self.send_json({"error": "会话已失效，请从启动器重新打开软件。"}, 403)
                    return
                if parsed.path == "/api/status":
                    self.send_json(state.public())
                elif parsed.path == "/api/settings":
                    with state.lock:
                        result = asdict(state.settings)
                        result["has_key"] = bool(state.session_key or __import__("os").environ.get("CRYSTAL_API_KEY"))
                    self.send_json(result)
                elif parsed.path == "/api/preview":
                    try:
                        query = parse_qs(parsed.query)
                        index, slot = int(query["index"][0]), int(query["slot"][0])
                        snapshot = state.public()
                        if index < 0 or index >= len(snapshot["results"]) or slot not in range(1, 8):
                            raise ValueError("bad index")
                        result = snapshot["results"][index]
                        if result["status"] not in {"completed", "reused"}:
                            raise ValueError("no preview")
                        path = Path(result["output"]) / f"{Path(result['file']).stem}-{slot}.jpg"
                        self.send_file(path)
                    except (KeyError, ValueError):
                        self.send_json({"error": "预览不可用。"}, 404)
                else:
                    self.send_json({"error": "未知接口。"}, 404)
            else:
                assets = {"/": "index.html", "/index.html": "index.html", "/app.js": "app.js", "/style.css": "style.css"}
                name = assets.get(parsed.path)
                if name:
                    self.send_file(resource_root() / "web" / name)
                else:
                    self.send_json({"error": "页面不存在。"}, 404)

        def do_POST(self):
            if not self.host_valid() or not self.authorized():
                self.send_json({"error": "会话无效。"}, 403)
                return
            try:
                count = int(self.headers.get("Content-Length", "0"))
                if count <= 0 or count > 100_000:
                    raise StudioError("请求大小无效。")
                payload = json.loads(self.rfile.read(count))
                if not isinstance(payload, dict):
                    raise StudioError("请求须为JSON对象。")
                route = urlparse(self.path).path
                if route == "/api/settings":
                    with state.lock:
                        if state.running:
                            raise StudioError("任务运行时请先停止或等待完成，再修改设置。")
                        updated = Settings.from_dict({**asdict(state.settings), **payload})
                        updated.save()
                        if payload.get("api_key", "").strip():
                            state.session_key = payload["api_key"].strip()
                        state.settings = updated
                    self.send_json({"ok": True})
                elif route in {"/api/batch", "/api/title", "/api/connection"}:
                    state.start(route.removeprefix("/api/"), payload)
                    self.send_json({"ok": True}, 202)
                elif route == "/api/cancel":
                    state.cancel.set()
                    state.event({"message": "已请求停止；当前AI请求返回后停止，已完成步骤会保留。"})
                    self.send_json({"ok": True})
                elif route == "/api/browse":
                    self.send_json({"path": browse(payload.get("kind", "folder"))})
                elif route == "/api/open-output":
                    path = Path(state.settings.output_dir).expanduser().resolve()
                    if not state.settings.output_dir or not path.is_dir():
                        raise StudioError("输出文件夹不存在。")
                    if sys.platform == "win32":
                        __import__("os").startfile(str(path))
                    elif sys.platform == "darwin":
                        subprocess.Popen(["open", str(path)])
                    else:
                        subprocess.Popen(["xdg-open", str(path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    self.send_json({"ok": True})
                else:
                    self.send_json({"error": "未知接口。"}, 404)
            except (StudioError, OSError, ValueError, TypeError, AttributeError) as exc:
                safe = str(exc)
                if state.session_key:
                    safe = safe.replace(state.session_key, "[密钥已隐藏]")
                self.send_json({"error": safe}, 400)

    return ThreadingHTTPServer(("127.0.0.1", port), Handler)
