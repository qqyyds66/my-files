from __future__ import annotations

import argparse
from dataclasses import asdict
import json
from pathlib import Path
import sys
import threading
import webbrowser

from .config import Settings, StudioError, api_key
from .pipeline import Pipeline
from .provider import GPTProvider
from .server import State, make_server


def main() -> int:
    parser = argparse.ArgumentParser(description="独立水晶球产品图片与标题工作室")
    parser.add_argument("command", nargs="?", choices=["desktop", "serve", "batch", "title", "check"], default="desktop")
    parser.add_argument("--port", type=int, default=0)
    parser.add_argument("--settings", type=Path)
    parser.add_argument("--text", default="")
    parser.add_argument("--image", type=Path)
    args = parser.parse_args()
    try:
        settings = Settings.from_dict(json.loads(args.settings.read_text(encoding="utf-8"))) if args.settings else Settings.load()
        if args.command in {"batch", "title", "check"}:
            provider = GPTProvider(settings, api_key())
            try:
                pipeline = Pipeline(settings, provider, notify=lambda event: print(event.get("message", ""), flush=True))
                if args.command == "check":
                    provider.check_models()
                    print("模型连接检查通过。")
                elif args.command == "batch":
                    results = pipeline.run()
                    return int(any(r["status"] == "failed" for r in results))
                else:
                    provider.check_models(images=False)
                    print(pipeline.titles(args.text, image=args.image))
            finally:
                provider.close()
            return 0
        state = State(settings)
        server = make_server(state, args.port)
        port = server.server_address[1]
        url = f"http://127.0.0.1:{port}/#{state.token}"
        if args.command == "serve":
            # The token is local session authorization, never the OpenAI API key.
            print(f"Local studio session: {url}", flush=True)
            try:
                server.serve_forever()
            except KeyboardInterrupt:
                pass
            finally:
                state.cancel.set()
                server.server_close()
        else:
            threading.Thread(target=server.serve_forever, daemon=True).start()
            try:
                try:
                    import webview
                except ImportError:
                    webbrowser.open(url)
                    print("软件已在本机浏览器打开。关闭此启动器会结束软件。", flush=True)
                    threading.Event().wait()
                else:
                    webview.create_window("水晶球工作室", url, width=1320, height=900, min_size=(900, 650))
                    webview.start()
            except KeyboardInterrupt:
                pass
            finally:
                state.cancel.set()
                server.shutdown()
                server.server_close()
        return 0
    except (StudioError, OSError, ValueError, TypeError) as exc:
        print(str(exc), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
