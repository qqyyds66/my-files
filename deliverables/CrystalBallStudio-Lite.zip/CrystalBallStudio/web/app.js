'use strict';
const token = location.hash.slice(1);
history.replaceState(null, '', location.pathname);
const fields = ['input_dir','output_dir','recursive','base_url','vision_model','image_model','photo_guide','diy_guide','quality','size','title_language','title_limit'];
const $ = id => document.getElementById(id);
let busy = false;
let lastState = null;
let lastResults = '';
const blobUrls = [];

function notice(message) { $('notice').textContent = message; $('notice').hidden = !message; }
async function api(path, data) {
  const options = {headers: {'X-Studio-Token': token}};
  if (data !== undefined) {options.method = 'POST'; options.headers['Content-Type'] = 'application/json'; options.body = JSON.stringify(data);}
  const response = await fetch(path, options);
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || '请求失败');
  return result;
}
function collect() {
  const data = {};
  for (const id of fields) data[id] = $(id).type === 'checkbox' ? $(id).checked : $(id).value;
  data.size = Number(data.size); data.title_limit = Number(data.title_limit);
  if ($('api_key').value.trim()) data.api_key = $('api_key').value.trim();
  return data;
}
async function save(show = true) {
  await api('/api/settings', collect());
  $('api_key').value = '';
  const saved = await api('/api/settings');
  $('key-state').textContent = saved.has_key ? '本次会话已有密钥。' : '尚未设置API Key。';
  if (show) notice('设置已保存。');
}
async function perform(action) {try {notice(''); await action();} catch (error) {notice(error.message);}}
function textElement(tag, value, className = '') { const element = document.createElement(tag); element.textContent = value; element.className = className; return element; }

for (const button of document.querySelectorAll('[data-panel]')) button.addEventListener('click', () => {
  document.querySelectorAll('.panel').forEach(panel => panel.hidden = panel.id !== button.dataset.panel);
  document.querySelectorAll('.nav').forEach(nav => nav.classList.toggle('active', nav === button));
  $('breadcrumb').textContent = button.querySelector('span').textContent;
});
for (const button of document.querySelectorAll('[data-browse]')) button.addEventListener('click', () => perform(async () => {
  const result = await api('/api/browse', {kind: button.dataset.kind});
  if (result.path) $(button.dataset.browse).value = result.path;
}));
$('save-settings').onclick = () => perform(() => save());
$('test-connection').onclick = () => perform(async () => {await save(false); await api('/api/connection', {}); await refresh();});
$('start-batch').onclick = () => perform(async () => {await save(false); await api('/api/batch', {}); await refresh();});
$('generate-title').onclick = () => perform(async () => {await save(false); await api('/api/title', {text: $('title-text').value, image: $('title-image').value}); await refresh();});
$('cancel').onclick = () => perform(async () => {await api('/api/cancel', {}); await refresh();});
$('open-output').onclick = () => perform(() => api('/api/open-output', {}));
$('copy-title').onclick = () => perform(async () => {
  if (!lastState || !lastState.title) throw new Error('请先生成标题。');
  try {await navigator.clipboard.writeText(lastState.title);} catch {
    const temp = document.createElement('textarea'); temp.value = lastState.title; document.body.appendChild(temp); temp.select();
    const ok = document.execCommand('copy'); temp.remove(); if (!ok) throw new Error('当前窗口无法复制，请选中标题后手动复制。');
  }
  notice('标题已复制。');
});

async function preview(index) {
  for (const url of blobUrls) URL.revokeObjectURL(url); blobUrls.length = 0;
  $('preview').replaceChildren();
  for (let slot = 1; slot <= 7; slot++) {
    const response = await fetch(`/api/preview?index=${index}&slot=${slot}`, {headers: {'X-Studio-Token': token}});
    if (!response.ok) throw new Error('商品图预览无法读取。');
    const url = URL.createObjectURL(await response.blob()); blobUrls.push(url);
    const figure = document.createElement('figure'), img = document.createElement('img'); img.src = url; img.alt = `商品图${slot}`;
    figure.append(img, textElement('figcaption', `-${slot}`)); $('preview').append(figure);
  }
}
function renderResults(results) {
  const signature = JSON.stringify(results); if (signature === lastResults) return; lastResults = signature;
  const container = $('results'); container.replaceChildren(); container.className = results.length ? '' : 'empty';
  if (!results.length) {container.textContent = '每张源图的结果与跳过原因会显示在这里。'; return;}
  const labels = {completed: '已完成', reused: '已复用', skipped: '已跳过', failed: '失败'};
  for (const [index,result] of results.entries()) {
    const row = textElement('div', '', 'result-row');
    row.append(textElement('span', result.file, 'result-name'), textElement('span', labels[result.status] || result.status, 'result-status ' + result.status), textElement('span', result.reason || result.output, 'result-reason'));
    if (['completed','reused'].includes(result.status)) {const button = textElement('button','预览7张'); button.onclick = () => perform(() => preview(index)); row.append(button);}
    container.append(row);
  }
}
async function refresh() {
  try {
    const state = await api('/api/status'); lastState = state; busy = state.running;
    for (const id of ['start-batch','generate-title','save-settings','test-connection']) $(id).disabled = busy;
    $('cancel').disabled = !busy;
    $('stage').textContent = state.stage; $('progress-count').textContent = `${state.current} / ${state.total}`;
    $('progress').max = Math.max(1,state.total); $('progress').value = busy ? Math.max(0,state.current - 1) : state.current;
    $('current-file').textContent = state.file || '先在设置面板选择两张固定说明图并配置GPT。';
    $('result-summary').textContent = state.results.length ? `${state.results.filter(r => ['completed','reused'].includes(r.status)).length} 套完成 / ${state.results.length} 张已处理` : '暂无任务';
    renderResults(state.results);
    $('logs').replaceChildren(...state.logs.map(log => textElement('div', `${log.time}  ${log.text}`)));
    $('title-result').textContent = state.title || '生成的标题会显示在这里。'; $('title-count').textContent = `${Array.from(state.title).length} 字符`;
    if (state.error) notice(state.error);
  } catch (error) {notice(error.message);}
}
perform(async () => {
  const settings = await api('/api/settings');
  for (const id of fields) {if ($(id).type === 'checkbox') $(id).checked = settings[id]; else $(id).value = settings[id];}
  $('key-state').textContent = settings.has_key ? '本次会话已有密钥。' : '尚未设置API Key。';
  await refresh();
});
setInterval(refresh,1500);
