@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo 请先运行“安装依赖.bat”。
  pause
  exit /b 1
)
.venv\Scripts\python.exe -m PyInstaller --noconfirm --clean --windowed --onedir --name CrystalBallStudio --add-data "web;web" --collect-all webview --hidden-import tkinter desktop.py
if errorlevel 1 (
  echo 打包失败，请检查上方错误信息。
  pause
  exit /b 1
)
echo 打包完成，软件位于 dist\CrystalBallStudio\CrystalBallStudio.exe。
echo 请分发整个 dist\CrystalBallStudio 文件夹。
pause
