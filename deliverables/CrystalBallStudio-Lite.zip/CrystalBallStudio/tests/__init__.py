"""Offline validation fixtures; no live AI credentials are used."""
