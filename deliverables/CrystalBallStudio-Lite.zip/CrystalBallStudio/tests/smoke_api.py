"""Local mock API + real studio server, exclusively for browser integration tests."""
import base64
import io
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import threading

from PIL import Image, ImageDraw

from crystalstudio.config import Settings
from crystalstudio.server import State, make_server
from tests.test_workflow import test_subject

ROOT = Path(__file__).resolve().parents[1] / "test-artifacts" / "browser-fixtures"
ROOT.mkdir(parents=True, exist_ok=True)
(ROOT / "input").mkdir(exist_ok=True)
Image.new("RGB", (500, 500), "white").save(ROOT / "input" / "测试商品.jpg")
for name in ("photo", "diy"):
    image = Image.new("RGB", (1200, 1200), "beige")
    ImageDraw.Draw(image).text((40, 40), "TEST FIXTURE - " + name, fill="black")
    image.save(ROOT / f"{name}.png")


def encoded(image):
    stream = io.BytesIO()
    image.save(stream, "PNG")
    return base64.b64encode(stream.getvalue()).decode()


class MockAPI(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def send(self, data):
        raw = json.dumps(data).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        if self.path != "/v1/models":
            self.send_error(404)
            return
        self.send({"data": [{"id": "gpt-6"}, {"id": "gpt-image-1.5"}]})

    def do_POST(self):
        body = self.rfile.read(int(self.headers.get("Content-Length", "0")))
        if self.path == "/v1/responses":
            data = json.loads(body)
            properties = data["text"]["format"]["schema"]["properties"]
            if "eligible" in properties:
                result = {"eligible": True, "confidence": .96, "reason": "mock wood base", "bbox": [.05, .05, .95, .95], "pattern": "test engraving"}
            elif "globe_bbox" in properties:
                result = {"ok": True, "confidence": .96, "reason": "mock fidelity", "globe_bbox": [.175, 30 / 440, .825, 290 / 440]}
            elif "title" in properties:
                result = {"title": "Warm LED Crystal Globe with Natural Wooden Base"}
            else:
                result = {"ok": True, "reason": "mock empty tabletop"}
            self.send({"status": "completed", "output": [{"type": "message", "content": [{"type": "output_text", "text": json.dumps(result)}]}]})
        elif self.path == "/v1/images/edits":
            self.send({"data": [{"b64_json": encoded(test_subject())}]})
        elif self.path == "/v1/images/generations":
            self.send({"data": [{"b64_json": encoded(Image.new("RGB", (1024, 1024), (228, 219, 203)))}]})
        else:
            self.send_error(404)


api_server = ThreadingHTTPServer(("127.0.0.1", 0), MockAPI)
threading.Thread(target=api_server.serve_forever, daemon=True).start()
settings = Settings(base_url=f"http://127.0.0.1:{api_server.server_address[1]}/v1",
                    input_dir=str(ROOT / "input"), output_dir=str(ROOT / "output"),
                    photo_guide=str(ROOT / "photo.png"), diy_guide=str(ROOT / "diy.png"))
state = State(settings)
state.session_key = "offline-test-key-not-a-real-credential"
server = make_server(state, 8788)
(ROOT / "session.json").write_text(json.dumps({"url": f"http://127.0.0.1:8788/#{state.token}"}), encoding="utf-8")
print("Offline browser integration fixture ready.", flush=True)
try:
    server.serve_forever()
except KeyboardInterrupt:
    pass
finally:
    state.cancel.set()
    server.server_close()
    api_server.shutdown()
    api_server.server_close()
