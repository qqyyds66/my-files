'use strict';
// Use the environment's existing Playwright and Chromium; no production API requests.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const {chromium} = require('playwright');

(async () => {
  const session=JSON.parse(fs.readFileSync('test-artifacts/browser-fixtures/session.json','utf8'));
  const browser = await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH || '/usr/bin/chromium'});
  try {
    const page = await browser.newPage({viewport:{width:1440,height:1100}});
    const errors=[]; page.on('pageerror',error=>errors.push(error.message));
    await page.goto(session.url);
    await page.waitForFunction(()=>document.getElementById('input_dir').value.length>0);
    await page.locator('#start-batch').click();
    await page.waitForFunction(()=>document.querySelector('#results .result-status')?.textContent === '已完成',{},{timeout:30000});
    await page.getByRole('button',{name:'预览7张'}).click();
    await page.waitForFunction(()=>document.querySelectorAll('#preview img').length===7);
    assert.equal(await page.locator('#preview img').count(),7);
    await page.locator('#start-batch').click();
    await page.waitForFunction(()=>document.querySelector('#results .result-status')?.textContent === '已复用',{},{timeout:30000});
    await page.getByRole('button',{name:'独立标题处理',exact:false}).click();
    await page.locator('#title-text').fill('transparent crystal, wood base, warm LED');
    await page.locator('#generate-title').click();
    await page.waitForFunction(()=>document.getElementById('title-result').textContent.includes('Natural Wooden Base'));
    await page.locator('#copy-title').click();
    await page.waitForFunction(()=>document.getElementById('notice').textContent.includes('已复制'));
    await page.getByRole('button',{name:'图片批处理',exact:false}).click();
    await page.screenshot({path:'test-artifacts/流程验证_模拟接口.png',fullPage:true});
    await page.setViewportSize({width:600,height:900});
    assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
    assert.deepEqual(errors,[]);
    console.log('PASS: real HTTP client + local mock API + browser batch, seven previews, resume, independent title, copy and responsive layout. No live AI calls.');
  } finally {await browser.close();}
})().catch(error=>{console.error(error);process.exitCode=1;});
