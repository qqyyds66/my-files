from __future__ import annotations

from dataclasses import asdict
import base64
import io
import json
from pathlib import Path
import tempfile
import threading
import unittest

import httpx
from PIL import Image, ImageDraw

from crystalstudio.config import Settings, StudioError
from crystalstudio.imaging import dimension_layout
from crystalstudio.pipeline import Cancelled, Pipeline, scan_images
from crystalstudio.provider import GPTProvider
from crystalstudio.server import State, make_server


def test_subject():
    image = Image.new("RGBA", (400, 440))
    draw = ImageDraw.Draw(image)
    draw.ellipse((70, 30, 330, 290), fill=(245, 222, 155, 180), outline=(255, 234, 150, 240), width=7)
    draw.rectangle((140, 115, 260, 120), fill=(255, 255, 255, 220))
    draw.rectangle((80, 290, 320, 375), fill=(157, 110, 57, 255))
    return image


class FakeProvider:
    """Deterministic test double, NEVER used by the application production mode."""
    def __init__(self, *, reject=False, fail_at=None, verify=True):
        self.calls = []
        self.reject = reject
        self.fail_at = fail_at
        self.verify = verify
        self.backgrounds = 0

    def check_models(self, *, images=True):
        self.calls.append("models")
        return ["gpt-6", "gpt-image-1.5"]

    def vision(self, prompt, images, schema, *, name="product_check"):
        properties = schema["properties"]
        if "eligible" in properties:
            self.calls.append("detect")
            return {"eligible": not self.reject, "confidence": .95, "reason": "符合规格" if not self.reject else "金属支架不符合规格", "bbox": [.05, .05, .95, .95], "pattern": "测试图案"}
        if "globe_bbox" in properties:
            self.calls.append("verify")
            return {"ok": self.verify, "confidence": .95, "reason": "一致" if self.verify else "内部图案已改变", "globe_bbox": [.175, 30 / 440, .825, 290 / 440]}
        if "title" in properties:
            self.calls.append("title")
            return {"title": "Warm LED Crystal Globe with Wooden Base"}
        self.calls.append("background_check")
        return {"ok": True, "reason": "空白台面"}

    def extract(self, image, prompt):
        self.calls.append("extract")
        return test_subject()

    def background(self, prompt):
        self.backgrounds += 1
        self.calls.append("background")
        if self.backgrounds == self.fail_at:
            raise StudioError("模拟连接超时")
        return Image.new("RGBA", (1024, 1024), (219, 207, 185, 255))


class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        source = self.root / "input"
        source.mkdir()
        Image.new("RGB", (500, 500), "white").save(source / "狗狗原图.jpg")
        for name, color in (("photo", "orange"), ("diy", "beige")):
            Image.new("RGB", (1200, 1200), color).save(self.root / f"{name}.png")
        self.settings = Settings(input_dir=str(source), output_dir=str(self.root / "output"),
                                 photo_guide=str(self.root / "photo.png"), diy_guide=str(self.root / "diy.png"))

    def tearDown(self):
        self.temp.cleanup()

    def test_seven_outputs_transparent_subject_and_zero_paid_calls_on_resume(self):
        provider = FakeProvider()
        results = Pipeline(self.settings, provider).run()
        self.assertEqual(results[0]["status"], "completed")
        output = Path(results[0]["output"])
        self.assertEqual(sorted(p.name for p in output.glob("*.jpg")), [f"狗狗原图-{i}.jpg" for i in range(1, 8)])
        for p in output.glob("*.jpg"):
            with Image.open(p) as image:
                self.assertEqual(image.size, (1200, 1200))
                image.verify()
        with Image.open(output / "提取主体/狗狗原图.png") as image:
            self.assertEqual(image.getchannel("A").getextrema()[0], 0)
        self.assertFalse(any("crop" in str(p) for p in output.rglob("*")))
        provider2 = FakeProvider()
        resumed = Pipeline(self.settings, provider2).run()
        self.assertEqual(resumed[0]["status"], "reused")
        self.assertEqual(provider2.calls, ["models"])

    def test_rejects_wrong_base_without_image_generation(self):
        provider = FakeProvider(reject=True)
        result = Pipeline(self.settings, provider).run()[0]
        self.assertEqual(result["status"], "skipped")
        self.assertEqual(provider.calls, ["models", "detect"])
        self.assertEqual(list(Path(result["output"]).glob("*.jpg")), [])

    def test_changed_engraving_stops_before_scenes(self):
        provider = FakeProvider(verify=False)
        result = Pipeline(self.settings, provider).run()[0]
        self.assertEqual(result["status"], "failed")
        self.assertIn("图案已改变", result["reason"])
        self.assertNotIn("background", provider.calls)
        self.assertFalse((Path(result["output"]) / "提取主体/狗狗原图.png").exists())

    def test_partial_failure_resumes_at_missing_scene(self):
        result = Pipeline(self.settings, FakeProvider(fail_at=3)).run()[0]
        self.assertEqual(result["status"], "failed")
        provider = FakeProvider()
        result2 = Pipeline(self.settings, provider).run()[0]
        self.assertEqual(result2["status"], "completed")
        self.assertEqual(provider.calls.count("background"), 2)
        self.assertNotIn("extract", provider.calls)
        self.assertNotIn("detect", provider.calls)

    def test_missing_fixed_card_and_name_collision_fail_before_model_calls(self):
        self.settings.photo_guide = ""
        provider = FakeProvider()
        with self.assertRaises(StudioError):
            Pipeline(self.settings, provider).run()
        self.assertEqual(provider.calls, [])
        self.settings.photo_guide = str(self.root / "photo.png")
        Image.new("RGB", (500, 500)).save(Path(self.settings.input_dir) / "狗狗原图.png")
        with self.assertRaises(StudioError):
            scan_images(self.settings)

    def test_existing_user_output_preserved(self):
        output = Path(self.settings.output_dir) / "狗狗原图"
        output.mkdir(parents=True)
        user_file = output / "保留.txt"
        user_file.write_text("existing user work", encoding="utf-8")
        provider = FakeProvider()
        result = Pipeline(self.settings, provider).run()[0]
        self.assertEqual(result["status"], "failed")
        self.assertEqual(user_file.read_text(), "existing user work")
        self.assertEqual(provider.calls, ["models"])

    def test_source_change_cannot_overwrite_completed_images(self):
        result = Pipeline(self.settings, FakeProvider()).run()[0]
        target = Path(result["output"]) / "狗狗原图-1.jpg"
        prior = target.read_bytes()
        Image.new("RGB", (500, 500), "blue").save(Path(self.settings.input_dir) / "狗狗原图.jpg")
        provider = FakeProvider()
        second = Pipeline(self.settings, provider).run()[0]
        self.assertEqual(second["status"], "failed")
        self.assertEqual(prior, target.read_bytes())
        self.assertNotIn("extract", provider.calls)

    def test_user_edit_of_generated_image_is_preserved(self):
        result = Pipeline(self.settings, FakeProvider()).run()[0]
        target = Path(result["output"]) / "狗狗原图-1.jpg"
        Image.new("RGB", (1200, 1200), "red").save(target)
        modified = target.read_bytes()
        second = Pipeline(self.settings, FakeProvider()).run()[0]
        self.assertEqual(second["status"], "failed")
        self.assertIn("外部修改", second["reason"])
        self.assertEqual(target.read_bytes(), modified)

    def test_cancel_does_not_start_a_paid_request(self):
        event = threading.Event()
        event.set()
        provider = FakeProvider()
        with self.assertRaises(Cancelled):
            Pipeline(self.settings, provider, cancel=event).run()
        self.assertEqual(provider.calls, [])

    def test_titles_are_independent_of_batch_and_fixed_assets(self):
        self.settings.photo_guide = self.settings.diy_guide = ""
        provider = FakeProvider()
        result = Pipeline(self.settings, provider).titles("wood base, warm LED")
        self.assertIn("Crystal", result)
        self.assertEqual(provider.calls, ["title"])
        self.assertFalse(Path(self.settings.output_dir).exists())

    def test_dimensions_use_true_globe_diameter_with_ratio_three_quarters(self):
        card = dimension_layout(test_subject(), [.175, 30 / 440, .825, 290 / 440], 1200)
        self.assertEqual(card.size, (1200, 1200))
        # Both rendered versions contain exactly the same distinctive base color.
        color = (157, 110, 57)
        widths = []
        for bounds in ((100, 200, 630, 710), (650, 200, 1120, 710)):
            region = card.crop(bounds)
            xs = [x for y in range(region.height) for x in range(region.width) if region.getpixel((x, y)) == color]
            self.assertTrue(xs)
            widths.append(max(xs) - min(xs) + 1)
        self.assertAlmostEqual(widths[1] / widths[0], .75, delta=.025)


class ProviderTests(unittest.TestCase):
    def test_responses_and_multipart_image_api_contract(self):
        settings = Settings()
        provider = GPTProvider(settings, "test-key-only")
        provider.client.close()
        calls = []
        buffer = io.BytesIO()
        test_subject().save(buffer, "PNG")
        encoded = base64.b64encode(buffer.getvalue()).decode()

        def handler(request):
            calls.append(request)
            self.assertEqual(request.headers["authorization"], "Bearer test-key-only")
            if request.url.path.endswith("/models"):
                return httpx.Response(200, json={"data": [{"id": settings.vision_model}, {"id": settings.image_model}]})
            if request.url.path.endswith("/responses"):
                payload = json.loads(request.content)
                self.assertEqual(payload["model"], "gpt-6")
                self.assertEqual(payload["text"]["format"]["type"], "json_schema")
                return httpx.Response(200, json={"status": "completed", "output": [{"type": "message", "content": [{"type": "output_text", "text": '{"title":"example"}'}]}]})
            self.assertTrue(request.url.path.endswith("/images/edits"))
            self.assertIn(b'name="background"', request.content)
            self.assertIn(b'transparent', request.content)
            self.assertIn(b'filename="reference.png"', request.content)
            return httpx.Response(200, json={"data": [{"b64_json": encoded}]})

        provider.client = httpx.Client(base_url="https://api.openai.com/v1/", headers={"Authorization": "Bearer test-key-only"}, transport=httpx.MockTransport(handler))
        try:
            self.assertEqual(len(provider.check_models()), 2)
            result = provider.vision("title", [], {"type": "object", "properties": {"title": {"type": "string"}}})
            self.assertEqual(result["title"], "example")
            self.assertEqual(provider.extract(test_subject(), "extract").mode, "RGBA")
            self.assertEqual(len(calls), 3)
        finally:
            provider.close()

    def test_missing_requested_gpt_model_has_no_silent_fallback(self):
        provider = GPTProvider(Settings(), "test-key-only")
        provider.client.close()
        provider.client = httpx.Client(base_url="https://api.openai.com/v1/", transport=httpx.MockTransport(lambda request: httpx.Response(200, json={"data": [{"id": "gpt-4.1"}]})))
        try:
            with self.assertRaisesRegex(StudioError, "gpt-6"):
                provider.check_models()
        finally:
            provider.close()

    def test_api_error_redacts_secret(self):
        provider = GPTProvider(Settings(), "secret-test-value")
        provider.client.close()
        provider.client = httpx.Client(base_url="https://api.openai.com/v1/", transport=httpx.MockTransport(lambda request: httpx.Response(401, json={"error": {"message": "Invalid secret-test-value"}})))
        try:
            with self.assertRaises(StudioError) as caught:
                provider.check_models()
            self.assertNotIn("secret-test-value", str(caught.exception))
        finally:
            provider.close()


class ServerTests(unittest.TestCase):
    def setUp(self):
        self.state = State(Settings())
        self.server = make_server(self.state)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.client = httpx.Client(base_url=f"http://127.0.0.1:{self.server.server_address[1]}")

    def tearDown(self):
        self.client.close()
        self.server.shutdown()
        self.server.server_close()

    def test_ui_serves_and_private_state_requires_session(self):
        page = self.client.get("/")
        self.assertEqual(page.status_code, 200)
        self.assertIn("独立标题处理", page.text)
        self.assertEqual(self.client.get("/api/settings").status_code, 403)
        result = self.client.get("/api/settings", headers={"X-Studio-Token": self.state.token})
        self.assertEqual(result.status_code, 200)
        self.assertNotIn("api_key", result.json())
        self.assertEqual(result.json()["vision_model"], "gpt-6")

    def test_no_key_produces_actionable_error_and_never_starts_job(self):
        result = self.client.post("/api/batch", json={}, headers={"X-Studio-Token": self.state.token})
        self.assertEqual(result.status_code, 400)
        self.assertIn("API Key", result.json()["error"])
        self.assertFalse(self.state.running)

    def test_rejects_path_traversal_and_invalid_host(self):
        self.assertEqual(self.client.get("/web/../../requirements.txt").status_code, 404)
        self.assertEqual(self.client.get("/", headers={"Host": "untrusted.example"}).status_code, 403)


if __name__ == "__main__":
    unittest.main()
