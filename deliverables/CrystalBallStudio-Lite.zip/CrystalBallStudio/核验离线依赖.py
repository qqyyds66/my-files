"""Verify packaged dependency files before offline installation."""
import hashlib
from pathlib import Path
import sys

root = Path(__file__).resolve().parent / "wheels"
try:
    lines = (root / "SHA256SUMS.txt").read_text(encoding="utf-8").splitlines()
    if not lines:
        raise ValueError("校验记录为空")
    for line in lines:
        expected, name = line.split("  ", 1)
        if Path(name).name != name:
            raise ValueError("校验记录中的文件名无效")
        path = root / name
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != expected:
            raise ValueError(f"离线依赖损坏：{name}")
    print("离线依赖校验通过。")
except (OSError, ValueError) as exc:
    print(f"{exc}；请重新解压完整软件包。", file=sys.stderr)
    raise SystemExit(1)
